// PRODUCTOS
const productos = [
    // Adidas
    {
        id: "tennis 01",
        titulo: "tenis Samba OG",
        imagen: "./img/Adidas-Samba-OG-01.jpg",
        categoria: {
            nombre: "adidas",
            id: "adidas" // clave con el principal HTML
        },
        precio: 700000
    },
    {
        id: "tennis 02",
        titulo: "tenis ZX 22 Boost",
        imagen: "./img/Tenis_ZX_22_BOOST.jpg",
        categoria: {
            nombre: "tenis ZX 22 Boost",
            id: "adidas" // clave con el principal HTML id
        },
        precio: 700000
    },
    {
        id: "tennis 03",
        titulo: "tenis altos con paneles",
        imagen: "./img/TH.jpg",
        categoria: {
            nombre: "Abrigos",
            id: "adidas" // clave con el principal HTML id
        },
        precio: 650000
    },
    {
        id: "tennis 04",
        titulo: "tenis Tennis Hu de adidas Originals x Pharrell Wililams",
        imagen: "./img/th (1).JPG",
        categoria: {
            nombre: "Abrigos",
            id: "adidas" // clave con el principal HTML id
        },
        precio: 750000
    },
    {
        id: "tennis 05",
        titulo: "tenis Terrex Hyperblue Mid R.RDY",
        imagen: "./img/tenis Terrex Hyperblue Mid R.RDY.jpg",
        categoria: {
            nombre: "Abrigos",
            id: "adidas" // clave con el principal HTML id
        },
        precio: 700000
    },
    // nike
    {
        id: "tennis 02",
        titulo: "tenis Dunk Low Black/White",
        imagen: "./img/22.jpg",
        categoria: {
            nombre: "nike",
            id: "nike" // clave con el principal HTML id
        },
        precio: 450000
    },
    {
        id: "tennis 02",
        titulo: "Camiseta 02",
        imagen: "./img/thh.JPG",
        categoria: {
            nombre: "nike",
            id: "nike" // clave con el principal HTML id
        },
        precio: 400000
    },
    {
        id: "tennis 02",
        titulo: " Nike x Tom Sachs ",
        imagen: "./img/thr.JPG",
        categoria: {
            nombre: "nike",
            id: "nike" // clave con el principal HTML id
        },
        precio: 350000
    },
    {
        id: "tennis 02",
        titulo: "tenis Zoom Vomero 5 Black Sesame",
        imagen: "./img/Nike-Zoom-Vomero.JPG",
        categoria: {
            nombre: "nike",
            id: "nike" // clave con el principal HTML id
        },
        precio: 37000
    },
    {
        id: "tennis 02",
        titulo: "tenis Fontanka Waffle",
        imagen: "./img/lll.JPG",
        categoria: {
            nombre: "nike",
            id: "nike" // clave con el principal HTML id
        },
        precio: 40000
    },
    {
        id: "tennis 02",
        titulo: "tenis Revolution 6 NN",
        imagen: "./img/ññññ.JPG",
        categoria: {
            nombre: "nike",
            id: "nike" // clave con el principal HTML id
        },
        precio: 50000
    },
    {
        id: "tennis 02",
        titulo: "tenis Air Zoom Pegasus 37 Shield",
        imagen: "./img/nike-tenis-running.JPG",
        categoria: {
            nombre: "nike",
            id: "nike" // clave con el principal HTML id
        },
        precio: 450000
    },
    {
        id: "tennis 02",
        titulo: "tenis bajos Wearallday",
        imagen: "./img/th (2).JPG",
        categoria: {
            nombre: "nike",
            id: "nike" // clave con el principal HTML id
        },
        precio: 450000
    },
    // new balance
    {
        id: "tennis 03",
        titulo: "",
        imagen: "./img/Pantalon1.JPG",
        categoria: {
            nombre: "Pantalones",
            id: "new balance" // clave con el principal HTML id
        },
        precio: 450000
    },
    {
        id: "tennis 03",
        titulo: "Pantalón 02",
        imagen: "./img/pantalon2.JPG",
        categoria: {
            nombre: "Pantalones",
            id: "new balance" // clave con el principal HTML id
        },
        precio: 500000
    },
    {
        id: "tennis 03",
        titulo: "Pantalón 03",
        imagen: "./img/Pantalon3.JPG",
        categoria: {
            nombre: "Pantalones",
            id: "new balance" // clave con el principal HTML id
        },
        precio: 400000
    },
    {
        id: "tennis 03",
        titulo: "Pantalón 04",
        imagen: "./img/Pantalon4.JPG",
        categoria: {
            nombre: "Pantalones",
            id: "new balance" // clave con el principal HTML id
        },
        precio: 380000
    },
    {
        id: "tennis 03",
        titulo: "Pantalón 05",
        imagen: "./img/Pantalon5.JPG",
        categoria: {
            nombre: "Pantalones",
            id: "new balance" // clave con el principal HTML id
        },
        precio: 450000
    }
];

const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".boton-categoria");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
const numerito = document.querySelector("#numerito");

function cargarProductos(productosElegidos) {

    contenedorProductos.innerHTML = "";

    productosElegidos.forEach(producto => {

        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${producto.titulo}</h3>
                <p class="producto-precio">$${producto.precio}</p>
                <button class="producto-agregar" id="${producto.id}">Agregar</button>
            </div>
        `;

        contenedorProductos.append(div);
    })

    actualizarBotonesAgregar();
}

cargarProductos(productos);

botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {

        botonesCategorias.forEach(boton => boton.classList.remove("active"));
        e.currentTarget.classList.add("active");

        if (e.currentTarget.id != "todos") {
            const productoCategoria = productos.find(producto => producto.categoria.id === e.currentTarget.id);
            tituloPrincipal.innerText = productoCategoria.categoria.nombre;
            const productosBoton = productos.filter(producto => producto.categoria.id === e.currentTarget.id);
            cargarProductos(productosBoton);
        } else {
            tituloPrincipal.innerText = "Todos los productos";
            cargarProductos(productos);
        }

    })
});

function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");

    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}

let productosEnCarrito;

let productosEnCarritoLS = localStorage.getItem("productos-en-carrito");

if (productosEnCarritoLS) {
    productosEnCarrito = JSON.parse(productosEnCarritoLS);
    actualizarNumerito();
} else {
    productosEnCarrito = [];
}

function agregarAlCarrito(e) {
    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);

    if(productosEnCarrito.some(producto => producto.id === idBoton)) {
        const index = productosEnCarrito.findIndex(producto => producto.id === idBoton);
        productosEnCarrito[index].cantidad++;
    } else {
        productoAgregado.cantidad = 1;
        productosEnCarrito.push(productoAgregado);
    }

    actualizarNumerito();

    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
}

function actualizarNumerito() {
    let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    numerito.innerText = nuevoNumerito;
}